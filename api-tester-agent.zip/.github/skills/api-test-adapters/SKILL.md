---
name: api-test-adapters
description: Framework detection, project profile template, and framework-specific implementation rules (REST Assured + TestNG/JUnit, Cucumber BDD + REST Assured, Serenity BDD) used by the api-tester agent. Load before writing API tests or creating .github/api-testing-profile.md.
---

# API Test Adapters

This skill holds everything framework-specific. The `api-tester` agent holds the workflow. To support a new framework, add one adapter section here — the agent does not change.

---

## 1. Framework Detection

Inspect the repo in this order and record evidence for each finding:

1. **Build tool:** `pom.xml` → Maven; `build.gradle` / `build.gradle.kts` → Gradle.
2. **Dependencies** (search the build file):

| Found | Meaning |
|---|---|
| `net.serenity-bdd:serenity-rest-assured` or `serenity-core` | Serenity BDD |
| `serenity-screenplay-rest` | Serenity Screenplay pattern |
| `io.cucumber:cucumber-java` (without Serenity) | Cucumber BDD |
| `io.rest-assured:rest-assured` (alone) | Plain REST Assured |
| `org.testng:testng` | TestNG runner |
| `org.junit.jupiter` / `junit:junit` | JUnit 5 / JUnit 4 |
| `json-schema-validator` | Schema validation available |
| `com.intuit.karate` | Karate — no adapter yet; ask: `1. Stop ⭐  2. Plan only (scenario matrix, no code)  3. Use <other style found> instead` |

3. **Choose the style** (first match wins):
   - Serenity + Screenplay → `serenity-screenplay`
   - Serenity + Cucumber → `serenity-cucumber`
   - Serenity (no Cucumber) → `serenity-junit`
   - Cucumber + REST Assured → `cucumber-restassured`
   - REST Assured + TestNG → `restassured-testng`
   - REST Assured + JUnit → `restassured-junit`
4. **Conventions** — find and record:
   - Base test class / request specification / API client layer (look for classes extending a common base, `RequestSpecification`, `RequestSpecBuilder`, `*Client`, `*Service`, `*Api`).
   - Where config and environments live (`serenity.conf`, `*.properties`, `config/*.yaml`, env variables) and how base URL / tokens are read.
   - Auth helper (token generation, filters).
   - Payload approach: POJOs + Jackson/Gson, builder pattern, JSON template files, or Maps.
   - Folders for tests, features, step defs, POJOs, schemas, test data.
   - Assertion library: Hamcrest, AssertJ, TestNG/JUnit asserts, Serenity `Ensure`.
   - Tags/groups convention (`@smoke`, `@regression`, `groups = {...}`).
   - The single most similar existing API test (record its path as the reference test).
   - **Run commands:** copy them from what the team already uses — CI pipeline files (`Jenkinsfile`, `.gitlab-ci.yml`, `.github/workflows/*.yml`, `.woodpecker.yml`), `README`, or Maven/Gradle profiles. Only fall back to the defaults in section 2 if nothing is found, and say so.
   - Test framework versions that change syntax: Cucumber version (tag filter syntax) and JUnit 4 vs 5.
5. **Collect option candidates** for the first-run questions (Q-SETUP in the agent file), each with its evidence:
   - every framework style found (dependency + version), ranked by how many existing API tests use it;
   - the 3 existing API tests most similar to the target API (same HTTP method, same auth, same resource area);
   - environment names from config (`serenity.conf` environments, `application-<env>.properties`, `config/<env>.yaml`), **excluding** anything named or pointing at production;
   - run commands found in CI files / README, plus the build tool's default.
6. If something can't be found, write `none` in the profile rather than guessing, and say so in the question message.

---

## 2. Profile Template

Save as `.github/api-testing-profile.md` after the tester confirms. Teams may edit it by hand.

```markdown
# API Testing Profile
style: <one of the styles above>
build_tool: maven | gradle
java_version: <from build file>

## Run commands (copied from CI/README where possible)
compile: <Maven: mvn -q test-compile | Gradle: ./gradlew testClasses>
run_single: <Maven: mvn test -Dtest=CreateUserApiTest | Gradle: ./gradlew test --tests "*CreateUserApiTest" | Cucumber: mvn verify -Dcucumber.filter.tags="@API_CreateUser">
report_path: <e.g. target/site/serenity/index.html | target/surefire-reports | build/reports/tests/test/index.html>

## Paths
tests: src/test/java/<pkg>/api/
features: src/test/resources/features/api/        # BDD only
step_definitions: src/test/java/<pkg>/stepdefs/   # BDD only
pojos: src/test/java/<pkg>/models/
schemas: src/test/resources/schemas/
test_data: src/test/resources/testdata/

## Reuse
base_class: <FQN or none>
request_spec: <class/method that builds the RequestSpecification>
api_client_layer: <package or none>
auth_helper: <class/method>
config_source: <file + key used for base URL>
payload_style: pojo-jackson | pojo-builder | json-template | map
assertions: hamcrest | assertj | testng | junit | serenity-ensure
tags: <existing tag/group conventions>
scenario_id_format: API_<ShortApiName>_<TYPE>_<NN>   # change if the team uses another ID style (e.g. Jira test keys)
reference_test: <path of the most similar existing API test>

## Team rules (optional, edited by the team)
- <e.g. every test must have @smoke or @regression>
```

---

## 3. Common rules (all styles)

- Build requests through the existing request spec / client layer. Only create a new client class if none exists, and mirror the nearest one.
- One test class / feature file per API endpoint (or per resource if that is the repo's pattern).
- Negative and boundary cases are data-driven.
- Schema files: `<schemas>/<resource>/<operation>-<status>.json` (e.g. `users/create-201.json`) unless the repo already uses another pattern.
- Generate unique test data (timestamp/UUID or the repo's Faker utility); never depend on fixed IDs that may not exist.
- Delete created records in teardown (`@AfterMethod`, `@AfterEach`, Cucumber `@After` hook scoped by tag) when a delete API exists. If none exists, prefix test data so it is easy to find (e.g. `autotest_<timestamp>`) and say in the report that cleanup is manual.
- Read credentials only through the profile's `auth_helper` / config. If a test needs a token that isn't configured, stop and ask which env variable to use.

---

## 4. Adapters

### 4.1 `restassured-testng` / `restassured-junit`

**Structure**
- Test class: `<Resource><Operation>ApiTest` in `tests` path, extending `base_class` if one exists.
- Each test method name contains the scenario ID in readable form, e.g. `API_CreateUser_NEG_03_missingEmail_returns400`.
- TestNG: put type in `groups` (`"smoke"`, `"negative"`…) and the scenario ID in `description`. JUnit 5: `@Tag` for type, `@DisplayName` with the scenario ID.

**Data-driven negatives**
- TestNG: `@DataProvider(name = "invalidCreateUserPayloads")` returning `{scenarioId, payload, expectedStatus, expectedErrorField}`.
- JUnit 5: `@ParameterizedTest` + `@MethodSource`.
- JUnit 4: `@RunWith(Parameterized.class)` with `@Parameters`, or the `JUnitParams` library only if the repo already uses it. Tag with `@Category` if the repo does.

**Request/response pattern**
```java
given()
    .spec(requestSpec)                // from the repo's base/spec
    .body(payload)
.when()
    .post(USERS_ENDPOINT)
.then()
    .statusCode(201)
    .body(matchesJsonSchemaInClasspath("schemas/users/create-201.json"))
    .body("email", equalTo(payload.getEmail()));
```
- Endpoint paths go in the repo's constants/endpoints class if one exists.
- Prefer extracting the response to a POJO for multi-field assertions when that is the repo's pattern.

**Chaining:** pass IDs/tokens via the extracted response inside one test, or via `dependsOnMethods` only if the repo already uses it.

**Framework-specific questions** (ask in Step 2, only when the answer isn't obvious from the repo):
```
❓ Where should the new tests go?
   1. New class <tests path>/<Resource><Operation>ApiTest.java   ⭐ (one class per endpoint, like <reference test>)
   2. Add to existing <ExistingClass>.java (<n> tests for the same resource)
❓ Where should the negative/boundary data live?
   a. @DataProvider inside the new test class   ⭐ (as in <reference test>)
   b. Shared data class <found data class>
   c. JSON/CSV file under <test_data path>
❓ How do I build the request body?
   1. POJO <found model class, e.g. CreateUserRequest>   ⭐
   2. New POJO <proposed class> in <pojos path> (no model exists yet)
   3. JSON template <found template path>
```

---

### 4.2 `cucumber-restassured`

**Feature file** (in `features` path, one per endpoint):
```gherkin
@api @API_CreateUser
Feature: Create user API

  Background:
    Given the API client is authenticated as "admin"

  @smoke @API_CreateUser_POS_01
  Scenario: Create user with all mandatory fields
    Given a valid create user request
    When the client sends the create user request
    Then the response status code should be 201
    And the response should match schema "users/create-201.json"
    And the response field "email" should equal the request field "email"

  @negative
  Scenario Outline: <id> Create user with invalid "<field>"
    Given a valid create user request
    And the request field "<field>" is set to "<value>"
    When the client sends the create user request
    Then the response status code should be <status>
    And the error message should mention "<field>"

    Examples:
      | id                     | field | value         | status |
      | API_CreateUser_NEG_01  | email | [null]        | 400    |
      | API_CreateUser_NEG_02  | email | not-an-email  | 400    |
```
**Step definition rules (most important)**
1. **Search existing step definitions first** (grep the step text patterns). Reuse any step that already matches, even if wording differs slightly — adjust the feature wording to the existing step rather than creating a near-duplicate.
2. Only add steps that don't exist; keep them **generic and parameterised** (`the response status code should be {int}`, `the request field {string} is set to {string}`) so other APIs reuse them.
3. Endpoint-specific steps go in `<Resource>Steps`; generic HTTP/response steps go in the repo's common steps class (create `CommonApiSteps` only if none exists).
4. Share request/response between steps through the repo's existing mechanism (scenario context / DI with PicoContainer / Spring). Never use static mutable fields unless the repo already does.
5. Support special values `[null]`, `[empty]`, `[random]` in a single helper, not in each step. (Square brackets avoid confusion with Scenario Outline `<placeholders>`.) If the repo already has its own convention for these, use that instead.
6. Run by tag: `mvn test -Dcucumber.filter.tags="@API_CreateUser"` for Cucumber 5+. For Cucumber 4 or older use `-Dcucumber.options="--tags @API_CreateUser"`. Prefer the command the repo's CI already uses.

**Framework-specific questions** (ask in Step 2, only when the answer isn't obvious from the repo):
```
❓ Feature file for these scenarios?
   1. New file <features path>/<resource>/<operation>.feature   ⭐ (one feature per endpoint, like <reference feature>)
   2. Append to existing <found feature file> (<n> scenarios for the same resource)
❓ <n> steps don't exist yet. Where should they go?
   a. Generic ones in <found common steps class>, API-specific ones in new <Resource>Steps.java   ⭐
   b. All in new <Resource>Steps.java
   c. All in <found common steps class>
(Asked in Step 3, only if close matches are found while writing:)
❓ I found close matches for <n> steps. Reuse them?
   1. Yes — reword the feature to use the existing steps   ⭐ (no new code)
   2. No — create new steps
   (list each pair: "new wording" → existing step in <file:line>)
```

---

### 4.3 `serenity-junit` / `serenity-cucumber`

Same structure as 4.1 / 4.2, with these differences:
- Use `SerenityRest.given()` (or the repo's Serenity-aware spec), **not** plain `RestAssured.given()`, so requests/responses appear in the Serenity report.
- Assert with `restAssuredThat(response -> response.statusCode(201))` or the assertion style already used in the repo.
- Wrap reusable actions in `@Step` methods inside the repo's step library classes (e.g. `UserApiSteps`) so they appear as readable steps in the report; feature step definitions call these step-library methods.
- Base URL and environments come from `serenity.conf` (`environments { default { restapi.baseurl = ... } }`) via `EnvironmentSpecificConfiguration` — never hardcode.
- Run: `mvn clean verify -Dcucumber.filter.tags="@API_CreateUser"` or `-Dit.test=<Class>` per the repo, and point the tester to `target/site/serenity/index.html`.

**Framework-specific questions** (in addition to those in 4.1 / 4.2):
```
❓ Which step library should hold the new @Step methods?
   1. Existing <found step library, e.g. UserApiSteps.java>   ⭐ (same resource)
   2. New <Resource>ApiSteps.java in <step library package>
❓ Which serenity.conf environment?
   a. <env found, e.g. qa>   ⭐
   b. <other non-prod env>
   (environments pointing at production are never listed)
```

### 4.4 `serenity-screenplay`

- Actor: reuse the existing cast/actor setup; actor gets `CallAnApi.at(baseUrl)` from config.
- Actions: `Post.to(...)`, `Get.resource(...)`, `Put.to(...)`, `Delete.from(...)` with `.with(request -> request.body(payload))`.
- Put reusable API calls in **Task** classes (`CreateUser.withDetails(user)`); put response reads in **Question** classes.
- Assert with `actor.should(seeThatResponse("user is created", response -> response.statusCode(201)))` or `Ensure`.
- Follow the repo's existing tasks/questions packages; don't mix Screenplay with step-library style.

**Framework-specific questions:**
```
❓ Tasks for this API?
   1. Reuse <found Task, e.g. CreateUser>   ⭐ (already calls <endpoint>)
   2. New Task <proposed name> in <tasks package>
❓ Which actor?
   a. <actor name found in the cast setup, e.g. "Admin">   ⭐
   b. New actor — type the name and role
```

---

## 5. Adding a new adapter

To support another framework (e.g. Karate, a custom in-house wrapper):
1. Add its detection rule to section 1.
2. Add a new `### 4.x <style-name>` section covering: file structure, naming, data-driven pattern, request/assert pattern, chaining, run command, and its **framework-specific questions** in the numbered-option format.
3. No change to `api-tester.agent.md` is needed.
